const express = require("express");
const products = require("./data/products.json");
const PORT = process.env.PORT || 3001;
const app = express();

app.get("/api/products", (req, res) => {
  res.json(products);
});

app.get("/api/products/:id", (req, res) => {
  const returnedItem = products.find(
    (item) => item.id === parseInt(req.params.id)
  );
  if (returnedItem?.id) {
    res.json(returnedItem);
  } else {
    return res.status(404).json({
      message: `Product with id: ${parseInt(req.params.id)} was not found.`,
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server listening on ${PORT}`);
});
