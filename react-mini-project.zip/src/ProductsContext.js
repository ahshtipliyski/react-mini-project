import React, { useState, useEffect, createContext } from "react";
import axios from "axios";

export const ProductsContext = createContext();

export const ProductsProvider = (props) => {
  const [products, setProducts] = useState([]);
  const [cartItems, setCartItems] = useState([]);

  const providerValues = {
    products,
    cartItems,
    setCartItems,
  };

  useEffect(() => {
    const callProducts = async () => {
      const response = await axios.get("/api/products");
      if (response.data) {
        setProducts(response.data);
      } else {
        console.log("Error: no data returned from server");
      }
    };
    callProducts();
  }, []);

  return (
    <ProductsContext.Provider value={[providerValues]}>
      {props.children}
    </ProductsContext.Provider>
  );
};
