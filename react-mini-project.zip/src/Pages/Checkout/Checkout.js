import React, { useContext } from "react";
import { ProductsContext } from "../../ProductsContext";
import { Link } from "react-router-dom";
import CheckoutItem from "../../Components/CheckoutItem/CheckoutItem";
import Totals from "../../Components/Totals/Totals";
import "./Checkout.scss";

function Checkout() {
  const [providerValues] = useContext(ProductsContext);
  const itemsInCart = providerValues.cartItems.reduce(function (
    accumulator,
    currentValue
  ) {
    accumulator[currentValue.id] = accumulator[currentValue.id] || [];
    accumulator[currentValue.id].push(currentValue);
    return accumulator;
  },
  Object.create(null));
  const showContent = itemsInCart && Object.keys(itemsInCart).length > 0;
  return (
    <section className="checkout">
      {showContent ? (
        <div className="checkout__header">
          <h2>Your cart</h2>
          <hr />
        </div>
      ) : (
        ""
      )}
      <div className="checkout__container">
        {showContent ? (
          Object.keys(itemsInCart).map((key) => (
            <CheckoutItem
              key={key}
              item={itemsInCart[key][0]}
              itemsSelected={itemsInCart[key].length}
            />
          ))
        ) : (
          <div className="checkout__empty-cart">
            <h2>Your cart is empty</h2>
            <p>You have no items in your cart.</p>

            <Link to="/shop">
              <button>Go to the Products page</button>
            </Link>
          </div>
        )}
      </div>
      {showContent ? <Totals itemsInCart={itemsInCart} /> : ""}
    </section>
  );
}

export default Checkout;
