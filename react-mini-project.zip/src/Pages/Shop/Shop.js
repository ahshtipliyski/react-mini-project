import Products from "../../Components/Products/Products";
import "./Shop.scss";

function Shop() {
  return (
    <section className="shop">
      <Products />
    </section>
  );
}

export default Shop;
