import Hero from "../../Components/Hero/Hero";
import Products from "../../Components/Products/Products";
import "./Home.scss";

function Home() {
  return (
    <section className="home">
      <Hero />
      <Products featuredProducts={true} />
    </section>
  );
}

export default Home;
