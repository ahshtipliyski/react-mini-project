import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./Components/Header/Header";
import Home from "./Pages/Home/Home";
import Shop from "./Pages/Shop/Shop";
import Checkout from "./Pages/Checkout/Checkout";
import NotFound from "./Components/NotFound/NotFound";
import ScrollToTop from "./Components/ScrollToTop/ScrollToTop";
import Footer from "./Components/Footer/Footer";
import { ProductsProvider } from "./ProductsContext";
import "./App.scss";

function App() {
  return (
    <ProductsProvider>
      <div className="App">
        <Router>
          <Header />
          <ScrollToTop />
          <Routes>
            <Route exact path="/" element={<Home />}></Route>
            <Route exact path="/shop" element={<Shop />}></Route>
            <Route exact path="/checkout" element={<Checkout />}></Route>
            <Route path="*" element={<NotFound />}></Route>
          </Routes>
          <Footer />
        </Router>
      </div>
    </ProductsProvider>
  );
}

export default App;
