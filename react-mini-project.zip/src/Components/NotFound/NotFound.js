function NotFound() {
  return <div>not found</div>;
}

export default NotFound;
