import React, { useContext } from "react";
import { ProductsContext } from "../../ProductsContext";
import productImageUnavailable from "../../Assets/Images/product_image_unavailable.jpeg";
import "./Product.scss";

function Product({ product }) {
  const [providerValues] = useContext(ProductsContext);
  const handleAddToCart = (item) => {
    providerValues.setCartItems([...providerValues.cartItems, item]);
  };
  return (
    <div className="product">
      <div className="product__image-container">
        <img
          src={product.image ? product.image : productImageUnavailable}
          alt={product.name}
        />
        <button
          onClick={() => handleAddToCart(product)}
          className="product__addToCart-button"
        >
          Add to Cart
        </button>
      </div>
      <div className="product__description-container">
        <div className="product__description">
          <div className="product__name-price">
            <h4>
              {product.name}
              <br />
              <span>
                {product.aisle
                  ? `${product.inventory} avialable on aisle ${product.aisle}`
                  : "Available online only"}
              </span>
            </h4>
            <p>{product.price}</p>
          </div>
        </div>
      </div>
      {product.featured ? (
        <div className="product__featured">Featured</div>
      ) : (
        ""
      )}
    </div>
  );
}

export default Product;
