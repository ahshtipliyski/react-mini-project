import "./Hero.scss";
import { Link } from "react-router-dom";

function Hero() {
  return (
    <div className="hero">
      <div className="hero__container">
        <h1>We save your time</h1>
        <p>Great products are just around the corner</p>
        <Link to="/shop">
          <button>SHOP NOW</button>
        </Link>
      </div>
    </div>
  );
}

export default Hero;
