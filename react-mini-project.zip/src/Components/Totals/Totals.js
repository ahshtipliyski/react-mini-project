import React, { useContext } from "react";
import { ProductsContext } from "../../ProductsContext";
import "./Totals.scss";

function Totals({ itemsInCart }) {
  const [providerValues] = useContext(ProductsContext);
  // const [completeModal, setCompleteModal] = useState(false);
  const totals = providerValues.cartItems.reduce(function (
    accumulator,
    currentValue
  ) {
    return accumulator + Number(currentValue.price.replace(/[^0-9.]/g, ""));
  },
  0);
  const completeOrder = () => {
    const submitItems = Object.values(itemsInCart).map((item) => {
      return {
        product_id: item[0].id,
        price: item[0].price,
        name: item[0].name,
        quantity: item.length,
      };
    });
    // pass data to server
    console.log(JSON.stringify(submitItems));
    // open thank you modal
    // redirect to home page
  };
  return (
    <div className="totals">
      <hr />
      <div className="totals__container">
        <h4>Subtotal ({providerValues.cartItems.length} items):</h4>
        <h4>{`$${totals.toFixed(2)}`}</h4>
      </div>
      <hr />
      <div className="totals__button-container">
        <button onClick={() => completeOrder()}>Place the order</button>
      </div>
    </div>
  );
}

export default Totals;
