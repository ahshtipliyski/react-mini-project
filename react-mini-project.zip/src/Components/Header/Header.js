import React, { useContext } from "react";
import { NavLink } from "react-router-dom";
import { ProductsContext } from "../../ProductsContext";
import "./Header.scss";
import logo from "../../triangle.svg";

function Header() {
  const [{ cartItems }] = useContext(ProductsContext);
  // const [sidebar, setSidebar] = useState(false);
  // const toggleSidebar = () => setSidebar(!sidebar);

  return (
    <header className="nav-bar">
      <div className="nav-bar__container">
        <div className="nav-bar__logo-container">
          <div className="nav-bar__logo">
            <img src={logo} alt="react-logo" />
          </div>
          <div className="nav-bar__brand">Triangle Store</div>
        </div>
        <div className="nav-bar__links">
          <NavLink className="nav-bar__link" to="/">
            Home
          </NavLink>
          <NavLink className="nav-bar__link" to="/shop">
            Shop
          </NavLink>
          <NavLink className="nav-bar__link" to="/checkout">
            Checkout{" "}
            {cartItems?.length === 0 ? "" : <span>{cartItems?.length}</span>}
          </NavLink>
        </div>
      </div>
    </header>
  );
}

export default Header;
