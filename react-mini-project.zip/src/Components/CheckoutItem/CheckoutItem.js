import "./CheckoutItem.scss";

function CheckoutItem({ item, itemsSelected }) {
  return (
    <div className="checkout-item">
      <div className="checkout-item__container">
        <div className="checkout-item__image-container">
          <img src={item.image} alt={item.name} />
        </div>
        <div className="checkout-item__description-container">
          <div className="checkout-item__description">
            <div className="checkout-item__name-price">
              <h4>{item.name}</h4>
              <p>
                {item.price} x {itemsSelected}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default CheckoutItem;
