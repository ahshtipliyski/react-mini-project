import React, { useState, useEffect, useContext } from "react";
import { ProductsContext } from "../../ProductsContext";
import Product from "../Product/Product";
import "./Products.scss";
import axios from "axios";

function Products({ featuredProducts }) {
  const [providerValues] = useContext(ProductsContext);
  const featuredAvailableProducts = providerValues.products.filter(
    (product) =>
      (featuredProducts ? product.featured : true) && product.inventory > 0
  );
  const [productsToDisplay, setProductsToDisplay] = useState([
    ...featuredAvailableProducts,
  ]);
  const handleSearch = (e) => {
    const searchValue = e.target.value.toLowerCase() || "";
    const filteredProducts = featuredAvailableProducts?.filter((product) =>
      product.name.toLowerCase().includes(searchValue)
    );
    setProductsToDisplay(filteredProducts);
  };
  useEffect(() => {
    const callProducts = async () => {
      const response = await axios.get("/api/products");
      if (response.data) {
        const availableProducts = response.data?.filter(
          (product) => product.inventory > 0
        );
        setProductsToDisplay(availableProducts);
      } else {
        console.log("Error: no data returned from server");
      }
    };
    callProducts();
  }, []);
  return (
    <section className="products">
      <div className="products__header-search-container">
        <h2 className="products__header">
          {featuredProducts ? "Featured Products" : "All Products"}
        </h2>
        {featuredProducts ? (
          ""
        ) : (
          <div className="products__search-container">
            <input
              className="products__search-input"
              type="search"
              onChange={(e) => handleSearch(e)}
              placeholder="Search..."
              defaultValue=""
            />
          </div>
        )}
      </div>
      <hr />
      <h4 className="products__subheader">
        {featuredProducts
          ? "Products that our customers love."
          : "Our selection of high quality products."}
      </h4>
      <div className="products__container">
        {productsToDisplay && productsToDisplay.length > 0 ? (
          productsToDisplay.map((product) => (
            <Product
              key={product.id}
              product={product}
              featured={featuredProducts}
            />
          ))
        ) : (
          <div>There are no available products with your search criteria.</div>
        )}
      </div>
    </section>
  );
}

export default Products;
