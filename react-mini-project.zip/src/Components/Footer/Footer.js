import "./Footer.scss";
import instagramImage from "../../Assets/Icons/SVG/Icon-instagram.svg";
import facebookImage from "../../Assets/Icons/SVG/Icon-facebook.svg";
import twitterImage from "../../Assets/Icons/SVG/Icon-twitter.svg";

function Footer() {
  const year = new Date().getFullYear();
  const storeMangement = [
    {
      name: "John Smith",
      title: "Manager",
      address: "1st Main Street",
      region: "Toronto, Ontario L3L L3L",
      email: "info@triangle-store.com",
      id: 1,
    },
    {
      name: "Jane Doe",
      title: "Business Manager",
      address: "Working with regions",
      region: "US / South America / Japan",
      email: "jane.doe@triangle-store.com",
      id: 2,
    },
    {
      name: "Jack Doe",
      title: "Customer Service",
      address: "Regions",
      region: "US / CA / UK / EU / AU",
      email: "jack.doe@triangle-store.com",
      id: 3,
    },
  ];
  return (
    <footer className="contact">
      <div className="contact__container">
        <div className="contact__top-items">
          <div className="contact__header">
            <h2>Get In Touch</h2>
          </div>

          <div className="contact__icons">
            <a
              href="https://www.instagram.com/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <img src={instagramImage} alt="instagram" />
            </a>
            <a
              href="https://www.facebook.com/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <img src={facebookImage} alt="facebook" />
            </a>
            <a
              href="https://www.twitter.com/"
              target="_blank"
              rel="noopener noreferrer"
            >
              <img src={twitterImage} alt="twitter" />
            </a>
          </div>

          <a href="index.html">
            <img
              src="../assets/logos/Logo-bandsite.svg"
              alt=""
              className="contact__logo"
            />
          </a>
        </div>

        <div className="contact__people">
          {storeMangement.map((person) => {
            return (
              <div className="contact__person" key={person.id}>
                <div className="contact__sub-header">
                  <h4>{person.name}</h4>
                  <h4>{person.title}</h4>
                </div>
                <div className="contact__details">
                  <p>{person.address}</p>
                  <p>{person.region}</p>
                </div>
                <div className="contact__email">
                  <a href={`mailto:${person.email}`}>
                    <p>{person.email}</p>
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        <div className="contact__copyright">
          <p>Copyright Triangle Store &copy; {year} All Rights Reserved</p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
